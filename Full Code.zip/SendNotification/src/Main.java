import javax.swing.*;

public class Main {
    public static JFrame frame;

    public static void showMainPanel(){
        frame.setTitle("Send Notification");
        frame.getContentPane().add(new sendNotification().getRootPanel());
        frame.pack();
        frame.setVisible(true);
    }

    public static void showSubmitForm(String subject, String body){
        frame.setTitle("Submitted");
        frame.getContentPane().add(new submit().getSubmitPanel(subject, body));
        frame.setVisible(true);
    }

    public static void main(String[] args){
        frame = new JFrame("Send Notification");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        javax.swing.SwingUtilities.invokeLater(Main::showMainPanel);
    }
}