import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import java.util.Date;


public class sendNotification {
    private JTextField subjectField;
    private JTextArea bodyField;
    private JButton button1;
    private JPanel mainPanel;

    public sendNotification(){
        mainPanel.setPreferredSize(new Dimension(400,400));
        mainPanel.setBorder(new EmptyBorder(50,1,50,1));
        subjectField.setBorder(new EmptyBorder(1,1,1,1));
        bodyField.setBorder(new EmptyBorder(1,1,1,1));
        bodyField.setLineWrap(true);
        button1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (subjectField.getText().length() < 5) {
                    subjectField.setBorder(new LineBorder(Color.red,1));
                }else if (bodyField.getText().length() < 20){
                    bodyField.setBorder((new LineBorder(Color.red,1)));
                }else{
                    mainPanel.setVisible(false);
                    javax.swing.SwingUtilities.invokeLater(() -> Main.showSubmitForm(subjectField.getText(), bodyField.getText()));
                }
            }
        });

        subjectField.addFocusListener(new FocusAdapter() {
            @Override
            public void focusGained(FocusEvent e) {
                subjectField.setBorder(new EmptyBorder(1,1,1,1));
            }
        });

        bodyField.addFocusListener(new FocusAdapter() {
            @Override
            public  void focusGained(FocusEvent e){
                bodyField.setBorder((new EmptyBorder(1,1,1,1)));
            }
        });
    }

    public JPanel getRootPanel(){
        return mainPanel;
    }
}
