import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.KeyAdapter;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.Date;

public class submit {
    private JLabel adminLabel;
    private JLabel dateTime;
    private JLabel subjectLabel;
    private JLabel bodyLabel;
    private JPanel submitPanel;
    private JLabel back;


    public submit(){
        submitPanel.setPreferredSize(new Dimension(450,400));

        back.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));


        back.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseReleased(MouseEvent e) {
                JOptionPane.showMessageDialog(submitPanel,"Submit Window is temporary.\nIt will be changed to the actual window in future.");
                submitPanel.setVisible(false);
                javax.swing.SwingUtilities.invokeLater(Main::showMainPanel);
            }
        });
    }

    public JPanel getSubmitPanel(String subject,String body){
        adminLabel.setText("From Admin");
        dateTime.setText(new Date().toString());
        subjectLabel.setText(subject);
        bodyLabel.setText(body);
        return  submitPanel;
    }



}
