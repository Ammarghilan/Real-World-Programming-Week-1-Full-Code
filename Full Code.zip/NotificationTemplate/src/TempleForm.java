import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class TempleForm {
    private JTextArea textarea1;
    private JPanel panel1;
    private JTextField loreanIpsumTextField;
    private JTextField loreamIpsumTextField;
    private JTextArea textarea2;
    private JButton save;
    private JButton addWidget;


    public TempleForm(){
        panel1.setPreferredSize(new Dimension(600,600));
        panel1.setBorder(new EmptyBorder(50,0,50,0));

        textarea1.setLineWrap(true);
        textarea2.setLineWrap(true);
        addWidget.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JOptionPane.showMessageDialog(panel1,"This feature will be available in the future.");
            }
        });
        save.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JOptionPane.showMessageDialog(panel1,"This feature will be available in the future.");
            }
        });
    }

    public JPanel getPanel1(){
        return panel1;
    }
}




