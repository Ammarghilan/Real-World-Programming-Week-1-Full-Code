import javax.swing.*;

public class Main {

    public static void showPanel(){

        JFrame frame = new JFrame("Template");
        frame.getContentPane().add(new TempleForm().getPanel1());
        frame.pack();
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);

    }

    public static void main(String[] args) {
        javax.swing.SwingUtilities.invokeLater(Main::showPanel);
    }
}