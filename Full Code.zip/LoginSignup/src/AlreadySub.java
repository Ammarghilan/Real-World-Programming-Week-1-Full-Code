import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;


public class AlreadySub {
    private JPanel alreadySub;
    private JTextField username;
    private JTextField password;
    private JButton submit;
    private JLabel newAcc;

    public AlreadySub(){
        alreadySub.setPreferredSize(new Dimension(500,230));
        submit.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        newAcc.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));

        newAcc.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
            newAcc.setForeground(new Color(0, 119, 110));
            alreadySub.setVisible(false);
            javax.swing.SwingUtilities.invokeLater(Main::showNewSub);

            }
        });
    }

    public JPanel getRootPanel() {
        return alreadySub;
    }
}
