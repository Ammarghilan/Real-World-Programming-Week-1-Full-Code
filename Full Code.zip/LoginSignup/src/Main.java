import javax.swing.*;


public class Main {

    public static JFrame frame= new JFrame("Sign up");




    public static void showNewSub() {
        frame.setTitle("Sign up");
        frame.getContentPane().add(new NewSub().getRootPanel());
        frame.pack();
        frame.setVisible(true);
    }
    public static void showAlreadySub() {
        frame.setTitle("Log in");
        frame.getContentPane().add(new AlreadySub().getRootPanel());
        frame.setVisible(true);
    }
    public static void showSubmitted(String fName,String lName){
        frame.setTitle("Submitted");
        frame.getContentPane().add(new submitted().getRootPanel(fName,lName));
        frame.setVisible(true);

    }
    public static void main(String[] args){
        javax.swing.SwingUtilities.invokeLater(Main::showNewSub);
        }
}
