import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class EmailValidator {
    public boolean validate(String s) {
        String pattern = "^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@"
                + "[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$";

        return s.matches(pattern);

    }
}