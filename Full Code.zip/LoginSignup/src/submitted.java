import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class submitted {
    private JPanel submittedPanel;
    private JButton backButton;
    private JLabel Label;
    private JLabel nameLabel;


    public submitted(){
       submittedPanel.setPreferredSize(new Dimension(550,230));
       backButton.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        backButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                submittedPanel.setVisible(false);
                javax.swing.SwingUtilities.invokeLater(Main::showNewSub);

            }
        });
    }

    public JPanel getRootPanel(String fName,String lName) {
       nameLabel.setText(String.format("Thanks %s %s\n",fName,lName));
        return submittedPanel;
    }
}
