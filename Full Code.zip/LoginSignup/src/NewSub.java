import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;
import java.awt.*;
import java.awt.event.*;
import java.util.Arrays;

public class NewSub {
    private JPanel NewSub;
    private JTextField email;
    private JTextField fName;
    private JTextField username;
    private JPasswordField password;
    private JTextField lName;
    private JButton submit;
    private JLabel exists;
    private JPasswordField recheckPassword;
    private JLabel help;

    public NewSub() {
        NewSub.setBorder(new EmptyBorder(20, 20, 30, 20));
        NewSub.setPreferredSize(new Dimension(550, 230));
        submit.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        exists.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        username.setBorder(new EmptyBorder(1,1,1,1));
        email.setBorder(new EmptyBorder(1,1,1,1));
        fName.setBorder(new EmptyBorder(1,1,1,1));
        lName.setBorder(new EmptyBorder(1,1,1,1));
        password.setBorder(new EmptyBorder(1,1,1,1));
        recheckPassword.setBorder(new EmptyBorder(1,1,1,1));
        help.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));




        submit.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                EmailValidator emailValidator = new EmailValidator();
                if (!username.getText().trim().matches("^[a-zA-Z_]\\w{5,30}")){
                    username.setBorder(new LineBorder(Color.red));
                    return;
                }
                else if(!emailValidator.validate(email.getText().trim())) {
                    System.out.println("Invalid Email ID");
                    email.setBorder(new LineBorder(Color.red));
                    return;
                }
                else if (!fName.getText().trim().matches("^[A-Za-z]+")) {
                    fName.setBorder(new LineBorder(Color.red));
                }
                else if(!lName.getText().trim().matches("^[A-Za-z]*")){
                    lName.setBorder(new LineBorder(Color.red));
                }
                else if (String.valueOf(password.getPassword()).trim().length()<=8){
                    password.setBorder(new LineBorder(Color.red));
                }else if(String.valueOf(recheckPassword.getPassword()).trim().length() == 0){
                    recheckPassword.setBorder(new LineBorder(Color.red));
                } else if (!Arrays.equals(password.getPassword(), recheckPassword.getPassword())) {
                    password.setBorder(new LineBorder(Color.red));
                    recheckPassword.setBorder(new LineBorder(Color.red));

                }else{
                    NewSub.setVisible(false);
                    javax.swing.SwingUtilities.invokeLater(()->Main.showSubmitted(fName.getText().strip(),lName.getText().strip()));
                }

            }
        });
        username.addFocusListener(new FocusAdapter() {
            @Override
            public void focusGained(FocusEvent e) {
                username.setBorder(new EmptyBorder(1,1,1,1));
            }
        });
        email.addFocusListener(new FocusAdapter() {
            @Override
            public void focusGained(FocusEvent e) {
                email.setBorder(new EmptyBorder(1,1,1,1));
            }
        });
        fName.addFocusListener(new FocusAdapter() {
            @Override
            public void focusGained(FocusEvent e) {
                fName.setBorder(new EmptyBorder(1,1,1,1));
            }
        });
        lName.addFocusListener(new FocusAdapter() {
            @Override
            public void focusGained(FocusEvent e) {
                lName.setBorder(new EmptyBorder(1,1,1,1));
            }
        });
        password.addFocusListener(new FocusAdapter() {
            @Override
            public void focusGained(FocusEvent e) {
                password.setBorder(new EmptyBorder(1,1,1,1));
            }
        });
        recheckPassword.addFocusListener(new FocusAdapter() {
            @Override
            public void focusGained(FocusEvent e) {
                recheckPassword.setBorder(new EmptyBorder(1,1,1,1));
            }
        });
        help.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                JOptionPane.showMessageDialog(NewSub,"Username only contains alphabets and underscores and needs to be more than five character.\nEmail needs to be correct.\nFirst Name is required.\n Last Name is optional.\nPassword must be equal and more than seven characters.");
            }
        });
        exists.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                exists.setForeground(new Color(0, 119, 110));
                NewSub.setVisible(false);
                javax.swing.SwingUtilities.invokeLater(Main::showAlreadySub);

            }
        });
    }

    public JPanel getRootPanel() {
        return NewSub;
    }

}

