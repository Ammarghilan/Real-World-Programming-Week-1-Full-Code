import javax.sound.sampled.Line;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;
import javax.swing.border.MatteBorder;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class NotificationCenter {
    private JPanel rootPanel;
    private JLabel subject1;
    private JLabel body1;
    private JLabel subject2;
    private JLabel body2;

    public NotificationCenter(){
        rootPanel.setPreferredSize(new Dimension(800,300));
        body1.setBorder(new MatteBorder(new Insets(0,0,1,0),Color.black));
        body2.setBorder(new MatteBorder(new Insets(0,0,1,0),Color.black));
        body1.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        body2.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));

        body1.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseReleased(MouseEvent e) {
                JOptionPane.showMessageDialog(rootPanel,"This is the full preview of notification. 1 Read it and close it.");
            }
        });
        body2.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseReleased(MouseEvent e) {
                JOptionPane.showMessageDialog(rootPanel,"This is the full preview of notification 2. Read it and close it.");
            }
        });
    }


    public JPanel getRootPanel(){
        return rootPanel;
    }
}
